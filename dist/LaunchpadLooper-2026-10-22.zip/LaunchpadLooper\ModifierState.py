"""Estado de los botones superiores. Modulo puro, sin Live."""


class ModifierState(object):
    """Lleva que superiores estan abajo y en que orden, y decide que
    accion corresponde al soltar cada uno.

    press(name)      -> registra el boton abajo
    release(name)    -> 'undo' | 'toggle_fixed_length' | None
                        (el tap del pulso se registra al bajar, no al soltar)
    consume(name)    -> la pulsacion ya hizo algo (long press / acorde);
                        al soltar no debe hacer nada mas
    note_lateral_touch() -> se toco un lateral con un modificador abajo
    active()         -> modificador activo (el primero que bajo) o None
    chord_held()     -> True mientras los tres botones del acorde INIT
                        esten abajo
    """

    def __init__(self, modifier_names, chord_names):
        self._modifiers = tuple(modifier_names)
        if isinstance(chord_names, dict):
            self._chords = dict((key, tuple(value)) for key, value in chord_names.items())
        else:
            self._chords = {'init': tuple(chord_names)}
        self._held = []
        self._consumed = set()
        self._touched = set()

    def press(self, name):
        if name not in self._held:
            self._held.append(name)
        chord = self.held_chord()
        if chord is not None:
            for chord_name in self._chords[chord]:
                self._consumed.add(chord_name)

    def release(self, name):
        was_held = name in self._held
        if was_held:
            self._held.remove(name)
        consumed = name in self._consumed
        touched = name in self._touched
        self._consumed.discard(name)
        self._touched.discard(name)
        if not was_held or consumed:
            return None
        if name == 'undo':
            return 'undo'
        if name == 'fixed_length':
            if touched:
                return None
            return 'toggle_fixed_length'
        return None

    def consume(self, name):
        self._consumed.add(name)

    def note_lateral_touch(self):
        active = self.active()
        if active is not None:
            self._touched.add(active)

    def is_held(self, name):
        return name in self._held

    def active(self):
        for name in self._held:
            if name in self._modifiers:
                return name
        return None

    def held_chord(self):
        """Nombre del acorde cuyos botones estan todos abajo, o None."""
        for chord, names in self._chords.items():
            if all(name in self._held for name in names):
                return chord
        return None

    def chord_held(self):
        return self.held_chord() is not None
