"""Operaciones sobre objetos de Live por duck typing. Sin import Live:
las constantes de cuantizacion llegan por parametro."""

try:
    from . import consts
    from . import ClipGain
except (ImportError, ValueError):
    import consts
    import ClipGain


class ClipActions(object):

    def __init__(self, song, no_quantization, log=None):
        self._song = song
        self._no_q = no_quantization
        self._log = log or (lambda message: None)

    # -- helpers ----------------------------------------------------------

    def _undo_step(self, func):
        self._song.begin_undo_step()
        try:
            return func()
        finally:
            self._song.end_undo_step()

    def _guard(self, label, func):
        try:
            return func()
        except RuntimeError as error:
            self._log('LaunchpadLooper %s: %s' % (label, error))
            return False

    def record_length_beats(self, bars):
        song = self._song
        return 4.0 / song.signature_denominator * song.signature_numerator * bars

    # -- pads -------------------------------------------------------------

    def stop_immediately(self, slot):
        song = self._song
        saved = song.clip_trigger_quantization
        song.clip_trigger_quantization = self._no_q
        try:
            self._guard('stop_immediately', slot.stop)
        finally:
            song.clip_trigger_quantization = saved

    def record(self, slot, fixed_length_bars):
        """Arma la pista del slot (sin tocar otras) y dispara la grabacion.
        Devuelve True si la pista fue armada por esta llamada."""
        track = slot.canonical_parent
        if not track.can_be_armed:
            return False
        armed_by_us = False
        if not track.arm:
            track.arm = True
            armed_by_us = True
        if fixed_length_bars:
            length = self.record_length_beats(fixed_length_bars)
            quant = self._song.clip_trigger_quantization
            self._guard('record', lambda: slot.fire(record_length=length, launch_quantization=quant))
        else:
            self._guard('record', slot.fire)
        return armed_by_us

    def launch(self, slot):
        self._guard('launch', slot.fire)

    def close_recording(self, slot):
        self._guard('close_recording', slot.fire)

    def delete_clip(self, slot):
        if not slot.has_clip:
            return False
        return self._guard('delete_clip', lambda: (slot.delete_clip(), True)[1])

    def copy_clip(self, source, target):
        if not source.has_clip or target.has_clip:
            return False
        return self._guard('copy_clip', lambda: (source.duplicate_clip_to(target), True)[1])

    def quantize_clip(self, slot, grid, amount):
        if not slot.has_clip:
            return False
        return self._guard('quantize_clip', lambda: (slot.clip.quantize(grid, amount), True)[1])

    # -- pistas y filas ---------------------------------------------------

    def stop_track(self, track):
        self._guard('stop_track', track.stop_all_clips)

    def stop_row(self, tracks, row):
        for track in tracks:
            if track.playing_slot_index == row:
                self.stop_track(track)

    def delete_row(self, scene, snap_name):
        def work():
            for slot in scene.clip_slots:
                if slot.has_clip:
                    self._guard('delete_row', slot.delete_clip)
            if scene.name == snap_name:
                scene.name = ''
            return True
        return self._undo_step(work)

    # -- snapshot e INIT --------------------------------------------------

    def take_snapshot(self, scenes, target_row, copies, snap_name):
        def work():
            target_scene = scenes[target_row]
            for track_index, source_row in copies:
                source = scenes[source_row].clip_slots[track_index]
                target = target_scene.clip_slots[track_index]
                self.copy_clip(source, target)
            target_scene.name = snap_name
            return True
        return self._undo_step(work)

    def init_grid(self, scenes, num_tracks, snap_name):
        def work():
            for scene in scenes:
                for slot in list(scene.clip_slots)[:num_tracks]:
                    if slot.has_clip:
                        self._guard('init_grid', slot.delete_clip)
                if scene.name == snap_name:
                    scene.name = ''
            return True
        return self._undo_step(work)

    # -- bounce -----------------------------------------------------------

    def bounce_start(self, origin_slots, target_slot, length_beats, send_index, input_routing):
        """Sube los sends de los origenes, rutea y arma el destino y dispara
        la grabacion. Devuelve lo guardado para bounce_restore, o None si
        Live rechazo algo (en ese caso ya quedo todo repuesto)."""
        target_track = target_slot.canonical_parent
        saved = {
            'sends': [],
            'target_track': target_track,
            'input': target_track.current_input_routing,
            'monitor': target_track.current_monitoring_state,
            'arm': bool(target_track.arm),
        }
        try:
            for slot in origin_slots:
                track = slot.canonical_parent
                send = track.mixer_device.sends[send_index]
                saved['sends'].append((send, send.value))
                send.value = consts.BOUNCE_SEND_LEVEL
            target_track.current_input_routing = input_routing
            target_track.current_monitoring_state = consts.MONITOR_OFF
            target_track.arm = True
            target_slot.fire(record_length=float(length_beats),
                             launch_quantization=self._song.clip_trigger_quantization)
        except RuntimeError as error:
            self._log('LaunchpadLooper bounce_start: %s' % error)
            self.bounce_restore(saved)
            return None
        return saved

    def bounce_restore(self, saved):
        if not saved:
            return
        for send, value in saved.get('sends', []):
            self._guard('bounce_restore send', lambda s=send, v=value: setattr(s, 'value', v))
        track = saved.get('target_track')
        if track is not None:
            self._guard('bounce_restore input',
                        lambda: setattr(track, 'current_input_routing', saved['input']))
            self._guard('bounce_restore monitor',
                        lambda: setattr(track, 'current_monitoring_state', saved['monitor']))
            self._guard('bounce_restore arm', lambda: setattr(track, 'arm', saved['arm']))

    def bounce_cancel(self, target_slot):
        """Tira lo grabado si hay clip; si solo esta disparado, quita el disparo."""
        if target_slot.has_clip:
            self._guard('bounce_cancel', target_slot.delete_clip)
        else:
            self._guard('bounce_cancel', target_slot.stop)

    def stop_tracks(self, tracks):
        for track in tracks:
            self.stop_track(track)

    # -- gain de clip -----------------------------------------------------

    def set_gain_level(self, clip, calibration, index):
        """Fija el gain del clip en el nivel `index` de ClipGain.LEVELS_DB.
        Si la tabla no esta calibrada, calibra primero sobre este clip
        (biseccion leyendo gain_display_string). Todo en un solo paso de
        Undo. Devuelve True si pudo escribir."""
        def run():
            original = clip.gain
            try:
                if not calibration.is_done():
                    approx = calibration.calibrate(lambda v: setattr(clip, 'gain', v),
                                                   lambda: clip.gain_display_string)
                    if approx is None:
                        self._log('LaunchpadLooper gain: texto en dB ilegible, tabla aproximada')
                    elif approx:
                        self._log('LaunchpadLooper gain: niveles aproximados %s' % approx)
                clip.gain = float(calibration.value_for(index))
                return True
            except RuntimeError as error:
                self._log('LaunchpadLooper set_gain_level: %s' % error)
                try:
                    clip.gain = original
                except RuntimeError:
                    pass
                return False
        return self._undo_step(run)

    # -- globales ---------------------------------------------------------

    def undo(self):
        if getattr(self._song, 'can_undo', True):
            self._guard('undo', self._song.undo)

    def redo(self):
        if getattr(self._song, 'can_redo', True):
            self._guard('redo', self._song.redo)

    def set_tempo(self, tempo):
        self._song.tempo = max(consts.TEMPO_MIN, min(consts.TEMPO_MAX, float(tempo)))

    def toggle_metronome(self):
        self._song.metronome = not self._song.metronome
        return self._song.metronome
